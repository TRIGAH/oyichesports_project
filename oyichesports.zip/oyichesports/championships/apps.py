from django.apps import AppConfig


class ChampionshipsConfig(AppConfig):
    name = 'championships'
